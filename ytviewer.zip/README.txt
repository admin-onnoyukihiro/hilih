Sebelum membuka aplikasi ini harap Download aplikasi Python dan install

https://www.python.org/ftp/python/3.10.11/python-3.10.11-amd64.exe
  
#FiturAplikasi YtViewer
1. YouTube default, streaming , dan dukungan YouTube Music
2. Dukungan  multithreaded dan Dinamis
3. Unduh otomatis driver chrome (Auto Update)
4. Dukungan proxy Free / proxy API  Format Proxy http, https, socks4, socks5
5. chrome v80+ agen pengguna acak berdasarkan platform
6. kanvas, audio, font, pelindung sidik jari webgl, dan kebocoran IP dicegah dengan kontrol webrtc geolokasi, zona waktu, spoofing perujuk dapat menambahkan ekstensi ekstra di folder extension/custom_extension/
7. Tautan langsung atau cari kata kunci di YouTube lalu tonton video dengan mencocokkan judul video yang tepat
memodifikasi urls.txt, search.txt dan config.json dengan cepat tanpa memulai ulang program
8. Api HTTP di localhost dan database untuk menyimpan jumlah tampilan
9. File config. json untuk menyimpan pengaturan
melewati halaman persetujuan dan beberapa pop up lainnya
10. Menghemat bandwidth dengan mengurangi kualitas video
11. apat menyetel persentase durasi tontonan yang lebih tinggi (100%) untuk menambah waktu Tontonan, mengubah kecepatan pemutaran

# Sumber Lalu Lintas

1. Pencarian YouTube
2. Video yang Disarankan
3. Eksternal (Google, Yahoo, DuckDuckGo, Bing, Twitter)
4. Layar Akhir
5. Halaman Channel
6. Langsung atau tidak diketahui

thank you for my partner
	Ahmad Badar (badar found)
